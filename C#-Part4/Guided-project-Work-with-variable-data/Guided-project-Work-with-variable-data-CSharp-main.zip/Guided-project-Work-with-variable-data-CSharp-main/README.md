# Guided-project-Work-with-variable-data-in-CSharp

Starter and Solution code for the **Guided project**: "Work with variable data in C# console applications" from the Microsoft Learn collection "Getting started with C#"
